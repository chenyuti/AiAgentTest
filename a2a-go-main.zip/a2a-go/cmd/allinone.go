package cmd

import (
	"a2a-samples/config"

	"github.com/spf13/cobra"
	"trpc.group/trpc-go/trpc-go"
	"trpc.group/trpc-go/trpc-go/log"
)

var (
	allinoneCmd = &cobra.Command{
		Use:          "allinone",
		Short:        "",
		Long:         "all-in-one server",
		SilenceUsage: true,
		PersistentPreRun: func(cmd *cobra.Command, args []string) {
			if len(config.CmdlineFlags.TRPCConfig) != 0 {
				trpc.ServerConfigPath = config.CmdlineFlags.TRPCConfig
			}
		},
		Run: func(cmd *cobra.Command, args []string) {
			defer log.Sync()
			s := trpc.NewServer()
			// 初始化配置
			config.Init()

			registerDeepResearch(s)
			registerLbsHelper(s)
			registerURLReader(s)
			registerHost(s)
			registerOpenAICConnector(s)
			registerQQBotConnector(s)

			if err := s.Serve(); err != nil {
				log.Fatal(err)
			}
		},
	}
)

// init
func init() {
	allinoneCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.TRPCConfig, "config", "c",
		"./trpc_go.yaml", "trpc config file path")
	allinoneCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.ConfigProvider, "config-provider", "p",
		"file", "config provider")
	allinoneCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.MainConfigFilename, "main-config", "m",
		"config.yaml", "main config file path")
}
