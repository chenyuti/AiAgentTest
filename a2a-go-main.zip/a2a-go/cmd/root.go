package cmd

import (
	"github.com/spf13/cobra"
)

var (
	rootCmd = &cobra.Command{
		Use:          "a2a_samples",
		Short:        "a2a samples",
		Long:         "a2a samples command",
		SilenceUsage: true,
	}
)

func init() {
	rootCmd.AddCommand(urlReaderCmd)
	rootCmd.AddCommand(lbsHelperCmd)
	rootCmd.AddCommand(deepResearchCmd)
	rootCmd.AddCommand(hostCmd)
	rootCmd.AddCommand(openaiConnectorCmd)
	rootCmd.AddCommand(qqbotConnectorCmd)
	rootCmd.AddCommand(allinoneCmd)
}

func Execute() {
	_ = rootCmd.Execute()
}
