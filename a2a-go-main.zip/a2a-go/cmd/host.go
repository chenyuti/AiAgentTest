package cmd

import (
	"a2a-samples/agents/host"
	"a2a-samples/config"

	"github.com/spf13/cobra"
	_ "trpc.group/trpc-go/trpc-filter/debuglog"
	_ "trpc.group/trpc-go/trpc-filter/recovery"
	"trpc.group/trpc-go/trpc-go"
	thttp "trpc.group/trpc-go/trpc-go/http"
	"trpc.group/trpc-go/trpc-go/log"
	"trpc.group/trpc-go/trpc-go/server"
)

var (
	hostCmd = &cobra.Command{
		Use:          "host",
		Short:        "host",
		Long:         "host",
		SilenceUsage: true,
		PersistentPreRun: func(cmd *cobra.Command, args []string) {
			if len(config.CmdlineFlags.TRPCConfig) != 0 {
				trpc.ServerConfigPath = config.CmdlineFlags.TRPCConfig
			}
		},
		Run: func(cmd *cobra.Command, args []string) {
			defer log.Sync()
			s := trpc.NewServer()
			// 初始化配置
			config.Init()

			registerHost(s)

			if err := s.Serve(); err != nil {
				log.Fatal(err)
			}
		},
	}
)

func registerHost(s *server.Server) {
	agt, err := host.NewAgent()
	if err != nil {
		log.Fatal(err)
	}
	a2aServer, err := host.NewA2AServer(agt)
	if err != nil {
		log.Fatal(err)
	}
	thttp.RegisterNoProtocolServiceMux(
		s.Service("trpc.a2a_samples.host.A2AServerHandler"),
		a2aServer.Handler(),
	)
}

// init
func init() {
	hostCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.TRPCConfig, "config", "c",
		"./trpc_go.yaml", "trpc config file path")
	hostCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.ConfigProvider, "config-provider", "p",
		"file", "config provider")
	hostCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.MainConfigFilename, "main-config", "m",
		"config.yaml", "main config file path")
}
