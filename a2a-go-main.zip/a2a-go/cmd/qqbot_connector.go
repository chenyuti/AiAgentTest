package cmd

import (
	"a2a-samples/config"
	"a2a-samples/connector/qqbot"

	"github.com/spf13/cobra"
	"trpc.group/trpc-go/trpc-go"
	"trpc.group/trpc-go/trpc-go/log"
	"trpc.group/trpc-go/trpc-go/server"
)

var (
	qqbotConnectorCmd = &cobra.Command{
		Use:          "qqbot_connector",
		Short:        "",
		Long:         "connect agent and qqbot",
		SilenceUsage: true,
		PersistentPreRun: func(cmd *cobra.Command, args []string) {
			if len(config.CmdlineFlags.TRPCConfig) != 0 {
				trpc.ServerConfigPath = config.CmdlineFlags.TRPCConfig
			}
		},
		Run: func(cmd *cobra.Command, args []string) {
			defer log.Sync()
			s := trpc.NewServer()
			// 初始化配置
			config.Init()

			registerQQBotConnector(s)

			if err := s.Serve(); err != nil {
				log.Fatal(err)
			}
		},
	}
)

func registerQQBotConnector(s *server.Server) {
	qqbotProcessor, err := qqbot.NewProcessor()
	if err != nil {
		log.Fatal(err)
	}
	go qqbotProcessor.Start(trpc.BackgroundContext())
}

// init
func init() {
	qqbotConnectorCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.TRPCConfig, "config", "c",
		"./trpc_go.yaml", "trpc config file path")
	qqbotConnectorCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.ConfigProvider, "config-provider", "p",
		"file", "config provider")
	qqbotConnectorCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.MainConfigFilename, "main-config", "m",
		"config.yaml", "main config file path")
}
