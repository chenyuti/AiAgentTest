package cmd

import (
	"a2a-samples/config"
	"a2a-samples/connector/openai"

	"github.com/spf13/cobra"
	"trpc.group/trpc-go/trpc-go"
	thttp "trpc.group/trpc-go/trpc-go/http"
	"trpc.group/trpc-go/trpc-go/log"
	"trpc.group/trpc-go/trpc-go/server"
)

var (
	openaiConnectorCmd = &cobra.Command{
		Use:          "openai_connector",
		Short:        "",
		Long:         "connect agent with openai compatible server",
		SilenceUsage: true,
		PersistentPreRun: func(cmd *cobra.Command, args []string) {
			if len(config.CmdlineFlags.TRPCConfig) != 0 {
				trpc.ServerConfigPath = config.CmdlineFlags.TRPCConfig
			}
		},
		Run: func(cmd *cobra.Command, args []string) {
			defer log.Sync()
			s := trpc.NewServer()
			// 初始化配置
			config.Init()
			registerOpenAICConnector(s)
			if err := s.Serve(); err != nil {
				log.Fatal(err)
			}
		},
	}
)

func registerOpenAICConnector(s *server.Server) {
	thttp.RegisterNoProtocolServiceMux(
		s.Service("trpc.a2a_samples.openai_connector.Handler"),
		openai.NewOpenAIServer(),
	)
}

// init
func init() {
	openaiConnectorCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.TRPCConfig, "config", "c",
		"./trpc_go.yaml", "trpc config file path")
	openaiConnectorCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.ConfigProvider, "config-provider", "p",
		"file", "config provider")
	openaiConnectorCmd.PersistentFlags().StringVarP(&config.CmdlineFlags.MainConfigFilename, "main-config", "m",
		"config.yaml", "main config file path")
}
