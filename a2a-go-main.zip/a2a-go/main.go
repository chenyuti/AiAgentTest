package main

import (
	"a2a-samples/cmd"
)

func main() {
	cmd.Execute()
}
