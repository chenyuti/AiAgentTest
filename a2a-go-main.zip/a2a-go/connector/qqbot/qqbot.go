package qqbot

import (
	"a2a-samples/config"
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/google/uuid"
	"github.com/tencent-connect/botgo"
	"github.com/tencent-connect/botgo/dto"
	"github.com/tencent-connect/botgo/event"
	"github.com/tencent-connect/botgo/openapi"
	"github.com/tencent-connect/botgo/token"
	"github.com/tencent-connect/botgo/websocket"
	"go.uber.org/atomic"
	"golang.org/x/oauth2"
	a2aclient "trpc.group/trpc-go/trpc-a2a-go/client"
	"trpc.group/trpc-go/trpc-a2a-go/protocol"
	"trpc.group/trpc-go/trpc-go"
	"trpc.group/trpc-go/trpc-go/log"
)

type Processor struct {
	agentClient *a2aclient.A2AClient
	botToken    oauth2.TokenSource
	api         openapi.OpenAPI
	appID       string
	nextSeq     atomic.Uint32
}

func (p *Processor) Start(ctx context.Context) {
	// 获取 websocket 信息
	wsInfo, err := p.api.WS(ctx, nil, "")
	if err != nil {
		log.ErrorContextf(ctx, "failed to get webcoket info, err: %v", err)
	}

	var handler []interface{}
	// C2C消息
	var c2cHandler event.C2CMessageEventHandler = func(event *dto.WSPayload, data *dto.WSC2CMessageData) error {
		_ = trpc.Go(trpc.BackgroundContext(), time.Minute*10, func(ctx context.Context) {
			_ = p.c2cMessageEventHandler(ctx, event, data)
		})
		return nil
	}
	handler = append(handler, c2cHandler)
	intent := websocket.RegisterHandlers(
		handler...,
	)
	if err = botgo.NewSessionManager().Start(wsInfo, p.botToken, &intent); err != nil {
		log.FatalContextf(ctx, "failed to start qqbot, err: %v", err)
	}
}

func (p *Processor) c2cMessageEventHandler(ctx context.Context, event *dto.WSPayload,
	data *dto.WSC2CMessageData) error {
	userID := data.Author.ID

	ch := make(chan string)
	go func() {
		defer close(ch)

		initMessage := protocol.Message{
			Role:  "user",
			Parts: []protocol.Part{protocol.NewTextPart(data.Content)},
			Metadata: map[string]interface{}{
				"UserID": userID,
			},
		}
		taskChan, err := p.agentClient.StreamTask(ctx, protocol.SendTaskParams{
			ID:      uuid.New().String(),
			Message: initMessage,
		})
		if err != nil {
			log.ErrorContextf(ctx, "stream task fail, %v", err)
			return
		}
		for v := range taskChan {
			switch taskEvent := v.(type) {
			case protocol.TaskStatusUpdateEvent:
				var content string
				if taskEvent.Status.Message != nil {
					part, ok := taskEvent.Status.Message.Parts[0].(protocol.TextPart)
					if !ok {
						return
					}
					content = part.Text
				}
				ch <- content
			}
		}
	}()
	p.handleSendMessage(ctx, data, ch)
	return nil
}

func (p *Processor) genErrMessage(data dto.Message, err error) dto.APIMessage {
	return p.genTextMessage(data, fmt.Sprintf("处理异常:%v", err))
}

func (p *Processor) getNextSeq() uint32 {
	if p.nextSeq.Load() < 65535 {
		p.nextSeq.Store(uint32(time.Now().Unix()))
	}
	return p.nextSeq.Inc()
}

func (p *Processor) genTextMessage(data dto.Message, msg string) dto.APIMessage {
	return &dto.MessageToCreate{
		MsgType:   dto.TextMsg,
		Content:   msg,
		MsgID:     data.ID,
		MsgSeq:    p.getNextSeq(),
		Timestamp: time.Now().UnixMilli(),
	}
}

func (p *Processor) handleSendMessage(ctx context.Context, event *dto.WSC2CMessageData, ch chan string) {
	var buf = strings.Builder{}
	var streamID string
	var streamIndex int32

	ticker := time.NewTicker(time.Millisecond * 500)
	defer ticker.Stop()

	heartbeatTicker := time.NewTicker(time.Second * 9)
	defer ticker.Stop()

	running := true
	for running {
		select {
		case val, ok := <-ch:
			if !ok {
				running = false
				break
			}
			buf.WriteString(val)
		case <-ticker.C:
			if buf.Len() == 0 {
				break
			}
			msgToCreate := &dto.MessageToCreate{
				MsgType:   dto.MarkdownMsg,
				MsgID:     event.ID,
				Timestamp: time.Now().UnixMilli(),
				Stream: &dto.Stream{
					ID:    streamID,
					Index: streamIndex,
					State: 1,
				},
			}
			msgToCreate.MsgSeq = p.getNextSeq()
			msgToCreate.Markdown = &dto.Markdown{
				Content: buf.String(),
			}
			// 发送消息
			sendResp, err := p.api.PostC2CMessage(ctx, event.Author.ID, msgToCreate)
			if err != nil {
				log.ErrorContextf(ctx, "send message fail, err: %v", err)
				continue
			}

			streamIndex = streamIndex + 1
			streamID = sendResp.ID
			buf.Reset()
		case <-heartbeatTicker.C:
			msgToCreate := &dto.MessageToCreate{
				MsgType:   dto.MarkdownMsg,
				MsgID:     event.ID,
				Timestamp: time.Now().UnixMilli(),
				Stream: &dto.Stream{
					ID:    streamID,
					Index: streamIndex,
					State: 1,
				},
			}
			msgToCreate.MsgSeq = p.getNextSeq()
			msgToCreate.Markdown = &dto.Markdown{
				Content: buf.String(),
			}
			// 发送消息
			sendResp, err := p.api.PostC2CMessage(ctx, event.Author.ID, msgToCreate)
			if err != nil {
				log.ErrorContextf(ctx, "send message fail, err: %v", err)
				continue
			}
			streamIndex = streamIndex + 1
			streamID = sendResp.ID
			buf.Reset()
		}
	}

	// 发送最后一个分片
	msgToCreate := &dto.MessageToCreate{
		MsgType:   dto.MarkdownMsg,
		MsgID:     event.ID,
		Timestamp: time.Now().UnixMilli(),
		Stream: &dto.Stream{
			ID:    streamID,
			Index: streamIndex,
			State: 10,
		},
	}
	msgToCreate.MsgSeq = p.getNextSeq()
	msgToCreate.Markdown = &dto.Markdown{
		Content: buf.String(),
	}
	// 发送消息
	_, err := p.api.PostC2CMessage(ctx, event.Author.ID, msgToCreate)
	if err != nil {
		log.ErrorContextf(ctx, "send message fail, err: %v", err)
		return
	}
}

func NewProcessor() (*Processor, error) {
	cfg := config.GetMainConfig()

	credentials := &token.QQBotCredentials{
		AppID:     cfg.QQBotConnector.AppID,
		AppSecret: cfg.QQBotConnector.Secret,
	}

	// 加载 appid 和 token
	botToken := token.NewQQBotTokenSource(credentials)
	if err := token.StartRefreshAccessToken(context.Background(), botToken); err != nil {
		return nil, fmt.Errorf("failed to refresh token: %w", err)
	}
	botgo.SetLogger(log.DefaultLogger)

	// 初始化 openapi，正式环境
	api := botgo.NewOpenAPI(credentials.AppID, botToken).WithTimeout(5 * time.Second).SetDebug(false)

	a2aClient, err := a2aclient.NewA2AClient(cfg.QQBotConnector.Agent.ServerURL, a2aclient.WithTimeout(time.Minute*10))
	if err != nil {
		return nil, fmt.Errorf("failed to connect agent: %w", err)
	}

	process := &Processor{
		appID:       cfg.QQBotConnector.AppID,
		api:         api,
		botToken:    botToken,
		agentClient: a2aClient,
	}
	return process, nil
}
