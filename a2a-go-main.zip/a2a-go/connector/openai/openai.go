package openai

import (
	"a2a-samples/config"
	"a2a-samples/pkg/openai"
	"a2a-samples/pkg/openai/api"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	a2aclient "trpc.group/trpc-go/trpc-a2a-go/client"
	"trpc.group/trpc-go/trpc-a2a-go/protocol"
	"trpc.group/trpc-go/trpc-go/log"
)

func handleTaskStatusUpdateEvent(ctx context.Context, req api.ChatRequest, ch chan<- any,
	event protocol.TaskStatusUpdateEvent) {
	var content string
	if event.Status.Message != nil {
		part, ok := event.Status.Message.Parts[0].(protocol.TextPart)
		if !ok {
			return
		}
		content = part.Text
	}
	finalState := isFinalState(event.Status.State)
	if finalState {
		content = content + "[](task://done)"
	}
	res := api.ChatResponse{
		Model:     req.Model,
		CreatedAt: time.Now().UTC(),
		Message:   api.Message{Role: "assistant", Content: content},
	}
	ch <- res
}

type Server struct {
}

func NewOpenAIServer() http.Handler {
	s := &Server{}

	engine := gin.New()
	engine.ContextWithFallback = true
	engine.POST("/v1/chat/completions", openai.ChatMiddleware(), s.chatHandler)
	return engine.Handler()
}

var taskIDPattern = regexp.MustCompile(`\[]\(task://([^)]+)\)`)
var userIDPattern = regexp.MustCompile(`\[]\(user://([^)]+)\)`)

// isFinalState checks if a TaskState represents a terminal state.
func isFinalState(state protocol.TaskState) bool {
	return state == protocol.TaskStateCompleted ||
		state == protocol.TaskStateFailed ||
		state == protocol.TaskStateCanceled
}

func (s *Server) chatHandler(c *gin.Context) {
	var req api.ChatRequest
	if err := c.ShouldBindJSON(&req); errors.Is(err, io.EOF) {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": "missing request body"})
		return
	} else if err != nil {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var foundAgent bool
	var agentConfig config.AgentConfig
	for _, agent := range config.GetMainConfig().OpenAIConnector.Agents {
		if agent.Name == req.Model {
			foundAgent = true
			agentConfig = agent
			break
		}
	}
	if !foundAgent {
		c.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": fmt.Sprintf("agent %s not found", req.Model)})
		return
	}

	ch := make(chan any)
	go func() {
		defer close(ch)

		var taskID string
		var userID string

		func() {
			for _, msg := range req.Messages {
				if msg.Role != "assistant" {
					continue
				}

				taskIDMatches := taskIDPattern.FindAllStringSubmatch(msg.Content, -1)
				for _, match := range taskIDMatches {
					if len(match) >= 2 {
						id := match[1]
						if id == "done" {
							taskID = ""
						} else {
							taskID = id
						}
					}
				}

				userIDMatches := taskIDPattern.FindAllStringSubmatch(msg.Content, -1)
				for _, match := range userIDMatches {
					if len(match) >= 2 {
						userID = match[1]
					}
				}
			}
			return
		}()

		if taskID == "" {
			taskID = uuid.New().String()
			res := api.ChatResponse{
				Model:     req.Model,
				CreatedAt: time.Now().UTC(),
				Message:   api.Message{Role: "assistant", Content: fmt.Sprintf("[](task://%s)\n", taskID)},
				Done:      false,
			}
			ch <- res
		}

		if userID == "" {
			userID = "user:" + uuid.New().String()
			res := api.ChatResponse{
				Model:     req.Model,
				CreatedAt: time.Now().UTC(),
				Message:   api.Message{Role: "assistant", Content: fmt.Sprintf("[](user://%s)\n", userID)},
				Done:      false,
			}
			ch <- res
		}

		initMessage := protocol.Message{
			Role:  "user",
			Parts: []protocol.Part{protocol.NewTextPart(req.Messages[len(req.Messages)-1].Content)},
			Metadata: map[string]interface{}{
				"UserID": userID,
			},
		}

		// 客户端
		a2aClient, err := a2aclient.NewA2AClient(agentConfig.ServerURL, a2aclient.WithTimeout(time.Minute*10))
		if err != nil {
			ch <- gin.H{"error": err.Error()}
			return
		}

		taskChan, err := a2aClient.StreamTask(c, protocol.SendTaskParams{
			ID:      taskID,
			Message: initMessage,
		})
		if err != nil {
			ch <- gin.H{"error": err.Error()}
			return
		}

		for v := range taskChan {
			switch event := v.(type) {
			case protocol.TaskStatusUpdateEvent:
				handleTaskStatusUpdateEvent(c, req, ch, event)
			}
		}

		res := api.ChatResponse{
			Model:      req.Model,
			CreatedAt:  time.Now().UTC(),
			Message:    api.Message{Role: "assistant", Content: ""},
			Done:       true,
			DoneReason: "stop",
		}
		ch <- res
	}()

	streamResponse(c, ch)
}

func streamResponse(c *gin.Context, ch chan any) {
	c.Header("Content-Type", "application/x-ndjson")
	c.Stream(func(w io.Writer) bool {
		val, ok := <-ch
		if !ok {
			return false
		}

		bts, err := json.Marshal(val)
		if err != nil {
			log.InfoContextf(c, "streamResponse: json.Marshal failed with %v", err)
			return false
		}

		log.InfoContextf(c, "write: %s", bts)

		// Delineate chunks with new-line delimiter
		bts = append(bts, '\n')
		if _, err := w.Write(bts); err != nil {
			log.InfoContextf(c, "streamResponse: w.Write failed with %v", err)
			return false
		}

		return true
	})
}
