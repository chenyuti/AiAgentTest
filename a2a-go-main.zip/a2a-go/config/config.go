package config

import (
	"fmt"
	"sync/atomic"

	tconfig "trpc.group/trpc-go/trpc-go/config"
	"trpc.group/trpc-go/trpc-go/log"
)

var mainConfigValue atomic.Value

// CmdlineFlags 命令行参数
var CmdlineFlags = struct {
	ConfigProvider     string
	MainConfigFilename string
	TRPCConfig         string
}{}

// MainConfig 服务配置
type MainConfig struct {
	Tavily struct {
		APIKey string `yaml:"apikey"`
	} `yaml:"tavily"`
	AMap struct {
		ServerURL string `yaml:"server_url"`
	} `yaml:"amap"`
	Jina struct {
		APIKey string `yaml:"apikey"`
	} `yaml:"jina"`
	EdgeOnePages struct {
		ServerURL string `yaml:"server_url"`
	} `yaml:"edge_one_pages"`
	LLM struct {
		URL            string `yaml:"url"`
		APIKey         string `yaml:"apikey"`
		IntentModel    string `yaml:"intent_model"`
		ChatModel      string `yaml:"chat_model"`
		ReasoningModel string `yaml:"reasoning_model"`
	} `yaml:"llm"`
	Langfuse struct {
		Name      string `yaml:"name"`
		Host      string `yaml:"host"`
		PublicKey string `yaml:"public_key"`
		SecretKey string `yaml:"secret_key"`
	} `yaml:"langfuse"`
	OpenAIConnector struct {
		Agents []AgentConfig `yaml:"agents"`
	} `yaml:"openai_connector"`
	QQBotConnector struct {
		AppID  string      `yaml:"appid"`
		Secret string      `yaml:"secret"`
		Agent  AgentConfig `yaml:"agent"`
	} `yaml:"qqbot"`
	HostAgent struct {
		Agents []AgentConfig `yaml:"agents"`
	} `yaml:"host_agent"`
}

type AgentConfig struct {
	Name      string `yaml:"name"`
	ServerURL string `yaml:"server_url"`
	JwksURL   string `yaml:"jwks_url"`
	CardURL   string `yaml:"card_url"`
}

// Init 初始化配置
func Init() {
	LoadConfig(CmdlineFlags.ConfigProvider, "yaml",
		CmdlineFlags.MainConfigFilename, &MainConfig{}, &mainConfigValue)
}

// GetMainConfig 获取服务配置
func GetMainConfig() *MainConfig {
	return mainConfigValue.Load().(*MainConfig)
}

// LoadConfig 加载并监听一个配置文件，失败则 panic，filename 默认是 config 目录下的
func LoadConfig(provider string, unmarshalName string, filename string, dst interface{}, cfg *atomic.Value) {
	cb := func(path string, data []byte) {
		if err := tconfig.GetUnmarshaler(unmarshalName).Unmarshal(data, dst); err != nil {
			log.Errorf("config update failed: %+v", string(data))
			return
		}
		cfg.Store(dst)
		log.Infof("change config:%+v", dst)
	}
	LoadConfigWithCallback(provider, unmarshalName, filename, dst, cb)
	cfg.Store(dst)
}

// LoadConfigWithCallback 加载并监听一个配置文件，失败则 panic，filename 默认是 config 目录下的
func LoadConfigWithCallback(provider string, unmarshalName string, filename string, dst interface{},
	callbackFunc tconfig.ProviderCallback) {
	buf, err := tconfig.GetProvider(provider).Read(filename)
	if err != nil {
		panic(fmt.Errorf("err=%v, filename=%s", err, filename))
	}

	if err = tconfig.GetUnmarshaler(unmarshalName).Unmarshal(buf, dst); err != nil {
		panic(err)
	}
	log.Infof("set config:%+v", dst)
	cb := func(path string, data []byte) {
		if path == filename {
			callbackFunc(path, data)
		}
	}
	tconfig.GetProvider(provider).Watch(cb)
}
