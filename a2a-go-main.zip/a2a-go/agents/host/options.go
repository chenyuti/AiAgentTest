package host

import (
	"a2a-samples/agents/host/memory"
)

type options struct {
	memoryOptions []memory.Option
}

func defaultOptions() *options {
	return &options{}
}

// Option is a function that modifies the options
type Option func(*options)

func WithMemoryOptions(memoryOpts ...memory.Option) Option {
	return func(o *options) {
		o.memoryOptions = memoryOpts
	}
}
