# a2a-samples

本项目为多智能体（Multi-Agent）系统的示例实现，基于 Go 语言和 tRPC 框架，支持多种智能体（Agent）与任务管理能力，具备良好的可扩展性和分布式能力。支持对接 QQ 机器人、OpenAI 兼容 API、行程助手、深度研究、URL 内容解读等多种场景。

## 目录结构

```
.
├── cmd/                # 各子命令实现（host, lbshelper, deepresearch, urlreader, allinone, openai_connector, qqbot_connector）
├── agents/             # 各Agent核心实现（host, lbshelper, deepresearch, urlreader）
├── pkg/                # 公共库与工具（openai, tools, card, jwks等）
├── connector/          # 外部服务对接（openai, qqbot等）
├── config/             # 配置相关代码
├── go.mod/go.sum       # Go模块依赖
├── Makefile            # 构建脚本
└── README.md           # 项目说明
```

## 主要模块说明

- **host**：主控Agent，负责用户与QQ机器人对接，消息分发、上下文管理、任务流转。
- **lbshelper**：行程智能助手Agent，支持天气、路线、旅行规划等。
- **deepresearch**：深度研究Agent，支持联网搜索、链式推理、复杂问题分析。
- **urlreader**：URL内容解读Agent，自动抓取并总结网页内容，支持基于URL的问答。
- **openai_connector**：OpenAI兼容API服务，支持OpenAI风格的API调用。
- **qqbot_connector**：QQ机器人对接服务，实现与QQBot的消息互通。
- **allinone**：一体化服务，单进程同时启动所有Agent和对接服务，便于本地开发和测试。

## 安装与依赖

- Go 1.21 及以上版本
- Redis 6.0 及以上（推荐）

安装依赖：

```bash
go mod tidy
```

## 构建与运行

### 一键构建

```bash
make build
```

编译产物为 `bin/a2a_samples` 一个可执行文件。

### 运行方式

所有Agent和服务均通过子命令方式运行。例如：

- 运行 host agent：
  ```bash
  ./bin/a2a_samples host --config ./trpc_go.yaml --main-config ./config.yaml
  ```
- 运行 lbshelper agent：
  ```bash
  ./bin/a2a_samples lbshelper --config ./trpc_go.yaml --main-config ./config.yaml
  ```
- 运行 deepresearch agent：
  ```bash
  ./bin/a2a_samples deepresearch --config ./trpc_go.yaml --main-config ./config.yaml
  ```
- 运行 urlreader agent：
  ```bash
  ./bin/a2a_samples urlreader --config ./trpc_go.yaml --main-config ./config.yaml
  ```
- 运行 allinone 一体化模式（推荐本地开发调试）：
  ```bash
  ./bin/a2a_samples allinone --config ./trpc_go.yaml --main-config ./config.yaml
  ```
- 运行 openai 兼容API服务：
  ```bash
  ./bin/a2a_samples openai_connector --config ./trpc_go.yaml --main-config ./config.yaml
  ```
- 运行 qqbot 对接服务：
  ```bash
  ./bin/a2a_samples qqbot_connector --config ./trpc_go.yaml --main-config ./config.yaml
  ```

- 示例配置位于`examples/allinone`里

> 所有子命令均支持 `--config`（tRPC配置）和 `--main-config`（主业务配置）参数。

### 查看所有支持的子命令

```bash
./bin/a2a_samples --help
```

## 主要特性

- 多智能体协作，主控与领域Agent分工
- 任务与消息持久化，支持分布式与高可用
- 丰富的技能扩展（天气、路线、内容解读、深度搜索等）
- 支持推送通知、任务状态追踪
- 统一的A2A协议与tRPC服务框架

## 贡献与开发

欢迎提交Issue与PR，建议先阅读各模块下的代码与注释。开发前请确保本地Go与Redis环境可用。

## License

本项目遵循A2A Go实现的同一开源协议。

---

如需更详细的API、配置或二次开发说明，请参考各模块源码及注释，或补充具体需求。
