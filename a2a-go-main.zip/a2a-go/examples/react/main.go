/*
 * Copyright 2024 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package main

import (
	"context"
	"fmt"
	"log"

	"github.com/cloudwego/eino-ext/components/model/openai"
	einomcp "github.com/cloudwego/eino-ext/components/tool/mcp"
	"github.com/cloudwego/eino/components/prompt"
	"github.com/cloudwego/eino/components/tool"
	"github.com/cloudwego/eino/compose"
	"github.com/cloudwego/eino/schema"
	"github.com/mark3labs/mcp-go/client"
	"github.com/mark3labs/mcp-go/mcp"
)

var (
	amapURL = "https://mcp.amap.com/sse?key=xxxx"
	apiKey  = "xxxx"
	baseURL = "xxxx"
	model   = "xxxx"
)

func connectMCP(ctx context.Context, serverURL string) ([]tool.BaseTool, []*schema.ToolInfo, error) {
	cli, err := client.NewSSEMCPClient(serverURL)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to connect: %w", err)
	}
	err = cli.Start(ctx)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to restart: %w", err)
	}
	initRequest := mcp.InitializeRequest{}
	initRequest.Params.ProtocolVersion = mcp.LATEST_PROTOCOL_VERSION
	initRequest.Params.ClientInfo = mcp.Implementation{
		Name:    "go-client",
		Version: "1.0.0",
	}
	_, err = cli.Initialize(ctx, initRequest)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to initialize: %w", err)
	}
	tools, err := einomcp.GetTools(ctx, &einomcp.Config{Cli: cli})
	if err != nil {
		return nil, nil, fmt.Errorf("failed to get tools: %w", err)
	}
	var toolsInfo []*schema.ToolInfo
	for _, v := range tools {
		toolInfo, err := v.Info(ctx)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to get tool info: %w", err)
		}
		toolsInfo = append(toolsInfo, toolInfo)
	}
	return tools, toolsInfo, nil
}

type state struct {
	Messages []*schema.Message
}

func main() {
	ctx := context.Background()
	g := compose.NewGraph[map[string]any, *schema.Message](
		compose.WithGenLocalState(func(ctx context.Context) *state {
			return &state{}
		}))

	promptTemplate := prompt.FromMessages(
		schema.FString,
		schema.SystemMessage("你是一个智能助手，请帮我解决以下问题"),
		schema.UserMessage("{location}今天天气怎么样？"),
	)
	tools, toolsInfo, err := connectMCP(ctx, amapURL)
	if err != nil {
		panic(err)
	}
	chatModel, err := openai.NewChatModel(ctx, &openai.ChatModelConfig{
		APIKey:  apiKey,
		BaseURL: baseURL,
		Model:   model,
	})
	if err != nil {
		panic(err)
	}
	if err = chatModel.BindTools(toolsInfo); err != nil {
		panic(err)
	}
	toolsNode, err := compose.NewToolNode(ctx, &compose.ToolsNodeConfig{
		Tools: tools,
	})

	_ = g.AddChatTemplateNode("ChatTemplate", promptTemplate)
	_ = g.AddChatModelNode("ChatModel", chatModel,
		compose.WithStatePreHandler(
			func(ctx context.Context, in []*schema.Message, state *state) ([]*schema.Message, error) {
				state.Messages = append(state.Messages, in...)
				return state.Messages, nil
			},
		),
		compose.WithStatePostHandler(
			func(ctx context.Context, out *schema.Message, state *state) (*schema.Message, error) {
				state.Messages = append(state.Messages, out)
				return out, nil
			},
		),
	)
	_ = g.AddToolsNode("ToolNode", toolsNode)

	_ = g.AddEdge(compose.START, "ChatTemplate")
	_ = g.AddEdge("ChatTemplate", "ChatModel")
	_ = g.AddBranch("ChatModel", compose.NewGraphBranch(
		func(ctx context.Context, in *schema.Message) (endNode string, err error) {
			if len(in.ToolCalls) == 0 {
				return compose.END, nil
			}
			return "ToolNode", nil
		}, map[string]bool{
			"ToolNode":  true,
			compose.END: true,
		}))
	_ = g.AddEdge("ToolNode", "ChatModel")

	r, err := g.Compile(ctx, compose.WithMaxRunSteps(10))
	if err != nil {
		panic(err)
	}

	in := map[string]any{"location": "广州"}
	ret, err := r.Invoke(ctx, in)
	if err != nil {
		panic(err)
	}
	log.Println("invoke result: ", ret)
}
