package jwks

import (
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	"github.com/lestrrat-go/jwx/v2/jwk"
	"trpc.group/trpc-go/trpc-go/log"
)

var (
	// JWT verification settings
	jwksRefreshInterval = 15 * time.Minute
)

// Client manages fetching and caching JWKS for JWT verification.
type Client struct {
	jwksURL      string
	keyset       jwk.Set
	keysetMutex  sync.RWMutex
	lastRefresh  time.Time
	refreshMutex sync.Mutex
}

// NewClient creates a new JWKS client for JWT verification.
func NewClient(jwksURL string) *Client {
	client := &Client{
		jwksURL: jwksURL,
		keyset:  jwk.NewSet(),
	}

	// Fetch JWKS initially
	if err := client.RefreshJWKS(); err != nil {
		log.Errorf("Initial JWKS fetch failed: %v", err)
	} else {
		log.Infof("Initial JWKS fetch successful")
	}

	// Start a background goroutine to refresh JWKS periodically
	go client.StartPeriodicRefresh()

	return client
}

// StartPeriodicRefresh refreshes the JWKS periodically.
func (c *Client) StartPeriodicRefresh() {
	ticker := time.NewTicker(jwksRefreshInterval)
	defer ticker.Stop()

	for range ticker.C {
		if err := c.RefreshJWKS(); err != nil {
			log.Errorf("JWKS refresh failed: %v", err)
		} else {
			log.Infof("JWKS refreshed successfully")
		}
	}
}

// RefreshJWKS fetches the latest JWKS from the server.
func (c *Client) RefreshJWKS() error {
	c.refreshMutex.Lock()
	defer c.refreshMutex.Unlock()

	log.Infof("Refreshing JWKS from %s at %v", c.jwksURL, time.Now().Format(time.RFC3339))

	// Create HTTP client with timeout
	httpClient := &http.Client{
		Timeout: 10 * time.Second,
	}

	// Fetch JWKS
	keysetResp, err := httpClient.Get(c.jwksURL)
	if err != nil {
		return fmt.Errorf("failed to fetch JWKS: %w", err)
	}
	defer keysetResp.Body.Close()

	// Check if the response is valid
	if keysetResp.StatusCode != http.StatusOK {
		return fmt.Errorf("failed to fetch JWKS: HTTP %d", keysetResp.StatusCode)
	}

	// Read the response body
	keysetData, err := io.ReadAll(keysetResp.Body)
	if err != nil {
		return fmt.Errorf("failed to read JWKS: %w", err)
	}

	// Parse the JWKS
	keyset, err := jwk.Parse(keysetData)
	if err != nil {
		return fmt.Errorf("failed to parse JWKS: %w", err)
	}

	// Update the keyset
	c.keysetMutex.Lock()
	c.keyset = keyset
	c.lastRefresh = time.Now()
	keyCount := keyset.Len()
	c.keysetMutex.Unlock()

	log.Infof("JWKS refreshed successfully at %v. Keys found: %d",
		time.Now().Format(time.RFC3339), keyCount)
	return nil
}

// GetKeySet returns the current JWKS.
func (c *Client) GetKeySet() jwk.Set {
	c.keysetMutex.RLock()
	defer c.keysetMutex.RUnlock()
	return c.keyset
}
